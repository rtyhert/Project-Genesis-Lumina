#include "lip_sync_handler.h"
#include "live2d_model.h"
#include <algorithm>
#include <cmath>
#include <iostream>
namespace lumina {
class LipSyncHandler::Impl {public:    LipFrame previous_frame_;

LipFrame current_frame_;

double time_since_last_update_ = 0.0;

}
;

LipSyncHandler::LipSyncHandler(Live2DModel* model)    : model_(model), impl_(std::make_unique<Impl>()) {}
LipSyncHandler::~LipSyncHandler() = default;

void LipSyncHandler::SetLive2DModel(Live2DModel* model) {    model_ = model;

}
void LipSyncHandler::LoadFrames(const LipSyncData& data) {    LoadFrames(data.frames, data.total_duration);

}
void LipSyncHandler::LoadFrames(const std::vector<LipFrame>& frames, double total_duration) {    frames_ = frames;

total_duration_ = total_duration;

current_time_ = 0.0;

state_ = LipSyncState::Idle;

impl_->previous_frame_ = LipFrame{}
;

impl_->current_frame_ = LipFrame{}
;

impl_->time_since_last_update_ = 0.0;

if (!frames_.empty()) {        impl_->current_frame_ = frames_[0];

}
}
void LipSyncHandler::Update(double delta_time) {    if (state_ != LipSyncState::Playing) {        return;

}
    if (audio_time_source_) {        double audio_time = audio_time_source_();

if (audio_time >= 0.0) {            current_time_ = audio_time;

}
 else {            current_time_ += delta_time;

}
    }
 else {        current_time_ += delta_time;

}
    if (current_time_ >= total_duration_ && total_duration_ > 0.0) {        current_time_ = total_duration_;

state_ = LipSyncState::Finished;

if (!frames_.empty()) {            auto frame = frames_.back();

if (model_) {                model_->SetMouthOpen(static_cast<float>(frame.mouth_open * gain_));

}
            if (frame_cb_) {                frame_cb_(frame);

}
        }
        return;

}
    if (frames_.empty()) {        return;

}
    auto frame = InterpolateFrame(current_time_);

if (model_) {        float mouth = static_cast<float>(std::clamp(frame.mouth_open * gain_, 0.0, 1.0));

model_->SetMouthOpen(mouth);

}
    if (frame_cb_) {        frame_cb_(frame);

}
    impl_->previous_frame_ = impl_->current_frame_;

impl_->current_frame_ = frame;

impl_->time_since_last_update_ += delta_time;

}
bool LipSyncHandler::IsPlaying() const {    return state_ == LipSyncState::Playing;

}
void LipSyncHandler::Play() {    if (frames_.empty()) return;

if (state_ == LipSyncState::Finished) {        current_time_ = 0.0;

}
    state_ = LipSyncState::Playing;

}
void LipSyncHandler::Pause() {    if (state_ == LipSyncState::Playing) {        state_ = LipSyncState::Paused;

}
}
void LipSyncHandler::Stop() {    state_ = LipSyncState::Idle;

current_time_ = 0.0;

impl_->time_since_last_update_ = 0.0;

impl_->previous_frame_ = LipFrame{}
;

impl_->current_frame_ = LipFrame{}
;

if (!frames_.empty()) {        impl_->current_frame_ = frames_[0];

}
    if (model_) {        model_->SetMouthOpen(0.0f);

}
}
void LipSyncHandler::Seek(double time) {    current_time_ = std::clamp(time, 0.0, total_duration_);

impl_->time_since_last_update_ = 0.0;

}
void LipSyncHandler::SetAudioTimeSource(std::function<double()> time_source) {    audio_time_source_ = std::move(time_source);

}
void LipSyncHandler::ClearAudioTimeSource() {    audio_time_source_ = nullptr;

}
LipFrame LipSyncHandler::GetCurrentFrame() const {    return impl_->current_frame_;

}
LipFrame LipSyncHandler::InterpolateFrame(double time) const {    if (frames_.empty()) {        return LipFrame{}
;

}
    if (time <= frames_.front().time) {        return frames_.front();

}
    if (time >= frames_.back().time) {        return frames_.back();

}
    for (size_t i = 0;

i < frames_.size() - 1;

++i) {        const auto& cur = frames_[i];

const auto& nxt = frames_[i + 1];

if (time >= cur.time && time <= nxt.time) {            double range = nxt.time - cur.time;

if (range < 1e-8) {                return cur;

}
            double t = (time - cur.time) / range;

double alpha = interpolation_alpha_;

double smooth_t = t;

if (alpha > 0.0) {                smooth_t = t * (1.0 - 2.0 * alpha) +                           (t * t) * alpha +                           (t * (2.0 - t)) * alpha;

smooth_t = std::clamp(smooth_t, 0.0, 1.0);

}
            LipFrame result;

result.time = time;

result.mouth_open = cur.mouth_open + (nxt.mouth_open - cur.mouth_open) * smooth_t;

result.jaw_y = cur.jaw_y + (nxt.jaw_y - cur.jaw_y) * smooth_t;

result.tongue_x = cur.tongue_x + (nxt.tongue_x - cur.tongue_x) * smooth_t;

result.tongue_y = cur.tongue_y + (nxt.tongue_y - cur.tongue_y) * smooth_t;

result.lip_width = cur.lip_width + (nxt.lip_width - cur.lip_width) * smooth_t;

return result;

}
    }
    return frames_.back();

}
}
// 
namespace lumina
