import asyncio
import os
import signal
import logging
from pathlib import Path

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .server import LuminaServer
from .api_routes import router as api_router

log = logging.getLogger("lumina")


def create_app(server: LuminaServer) -> FastAPI:
    app = FastAPI(
        title="lumina-py",
        version="0.1.0",
        description="Lumina AI Backend - Virtual Human Live Streaming Platform",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.state.server = server

    app.include_router(api_router, prefix="/api/v1")

    @app.get("/health")
    async def health():
        return {"status": "healthy", "service": "lumina-py"}

    return app


def _can_use_signal_handlers() -> bool:
    return os.name != "nt"


async def main():
    config_path = Path(__file__).resolve().parent.parent / "config.yaml"
    server = LuminaServer(str(config_path))
    server.log.info("LuminaServer initialized")

    app = create_app(server)

    grpc_task = asyncio.create_task(server.start_grpc())

    rest_config = uvicorn.Config(
        app=app,
        host=server.cfg["server"].get("host", "0.0.0.0"),
        port=server.cfg["server"].get("rest_port", 8000),
        log_level="info",
        reload=server.cfg.get("hot_reload", False),
    )
    rest_server = uvicorn.Server(rest_config)

    shutdown_event = asyncio.Event()

    def _signal_handler():
        server.log.info("Shutdown signal received")
        shutdown_event.set()

    if _can_use_signal_handlers():
        loop = asyncio.get_event_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, _signal_handler)
    else:
        server.log.info("Signal handlers not available on Windows; use Ctrl+C to stop")

    server.log.info(
        f"Starting REST API on {rest_config.host}:{rest_config.port}, "
        f"gRPC on port {server.cfg['server']['port']}"
    )

    rest_task = asyncio.create_task(rest_server.serve())

    waiters = [grpc_task, rest_task, asyncio.create_task(shutdown_event.wait())]

    done, pending = await asyncio.wait(
        waiters,
        return_when=asyncio.FIRST_COMPLETED,
    )

    server.log.info("Shutting down gracefully...")
    for task in pending:
        task.cancel()

    rest_server.should_exit = True
    await server.neuro.stop()

    server.log.info("Shutdown complete")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log.info("Received keyboard interrupt")
